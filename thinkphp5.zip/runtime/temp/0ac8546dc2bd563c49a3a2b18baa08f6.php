<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:90:"C:\phpStudy\PHPTutorial\WWW\thinkphp5\public/../application/admin\view\index\prodlist.html";i:1701834440;s:84:"C:\phpStudy\PHPTutorial\WWW\thinkphp5\application\admin\view\index\admindivinfo.html";i:1701740560;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>编辑宠物</title>
    <link rel="stylesheet" href="/thinkphp5/public/static/css/common.css">
    <link rel="stylesheet" href="/thinkphp5/public/static/css/mystyle3.css">
    <link rel="stylesheet" href="/thinkphp5/public/static/css/mystyle7.css">
</head>
<body>
<h2>编辑宠物</h2>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<div class="info">
    <?php if(empty(\think\Session::get('user.username')) || ((\think\Session::get('user.username') instanceof \think\Collection || \think\Session::get('user.username') instanceof \think\Paginator ) && \think\Session::get('user.username')->isEmpty())): ?>
    <div class="welcome">
        <a href="<?php echo url('index/user/login'); ?>">登录</a>
        <a href="<?php echo url('index/user/register'); ?>">注册</a>
    </div>
    <?php else: ?>
    <div class="welcome">欢迎您！管理员（<?php echo \think\Session::get('user.username'); ?>）
    </div>
    <div class="funclist">
        <a href="<?php echo url('index/user/logout'); ?>">退出登录</a>
    </div>
    <?php endif; ?>
</div>
</body>
</html>
<div class="main">
    <div class="categorylist">
        <div class="category">
            <img src="/thinkphp5/public/static/commimages/btnnodeFunction.png" alt="" class="littleimg">
            <a href="<?php echo url('index/addproduct'); ?>">新增宠物</a>
        </div>
        <div class="category">
            <img src="/thinkphp5/public/static/commimages/btnnodeFunction.png" alt="" class="littleimg">
            <a href="<?php echo url('index/prodlist'); ?>">编辑宠物</a>
        </div>
        <div class="category">
            <img src="/thinkphp5/public/static/commimages/btnnodeFunction.png" alt="" class="littleimg">
            <a href="<?php echo url('index/adduser'); ?>">新增用户</a>
        </div>
        <div class="category">
            <img src="/thinkphp5/public/static/commimages/btnnodeFunction.png" alt="" class="littleimg">
            <a href="<?php echo url('index/userlist'); ?>">编辑用户</a>
        </div>
    </div>
    <div id="content">
        <div class="info2">
            <h3><strong>当前一共<span class="count"><?php echo $count; ?></span>种商品</strong></h3>
        </div>
        <div class="prodlist">
            <table id="table">
                <tr class="coltitle">
                    <td>操作</td>
                    <td>图片</td>
                    <td>名称</td>
                    <td>类别</td>
                    <td>单价</td>
                </tr>
        <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;if($mod == '1'): ?>
            <tr class="message">
                <td class="littletd">
                    <a href="<?php echo url('delproduct?pid='.$item['productid']); ?>">
                        <img src="/thinkphp5/public/static/commimages/btnDelete.png" alt="删除" class="btnimg">
                    </a>
                </td>
                <td>
                    <a href="<?php echo url('editproduct?pid='.$item['productid']); ?>">
                        <img src="/thinkphp5/public/static/<?php echo $item['image']; ?>" alt="<?php echo $item['productname']; ?>" class="proimg">
                    </a>
                </td>
                <td><?php echo $item['productname']; ?></td>
                <td><?php echo $item['name']; ?></td>
                <td><?php echo $item['unitprice']; ?></td>
            </tr>
        <?php endif; if($mod == '0'): ?>
            <tr class="message2">
                <td class="littletd">
                    <a href="<?php echo url('delproduct?pid='.$item['productid']); ?>">
                        <img src="/thinkphp5/public/static/commimages/btnDelete.png" alt="删除" class="btnimg">
                    </a>
                </td>
                <td class="littletd">
                    <a href="<?php echo url('editproduct?pid='.$item['productid']); ?>">
                        <img src="/thinkphp5/public/static/<?php echo $item['image']; ?>" alt="<?php echo $item['productname']; ?>" class="proimg">
                    </a>
                </td>
                <td><?php echo $item['productname']; ?></td>
                <td><?php echo $item['name']; ?></td>
                <td><?php echo $item['unitprice']; ?></td>
            </tr>
        <?php endif; endforeach; endif; else: echo "" ;endif; ?>
        </table>
            <div class="pages">
                <?php echo $list->render(); ?>
            </div>
        </div>
    </div>
</div>
</body>
</html>