<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:85:"C:\phpStudy\PHPTutorial\WWW\2077\public/../application/index\view\index\favorite.html";i:1701912820;s:77:"C:\phpStudy\PHPTutorial\WWW\2077\application\index\view\index\divwelcome.html";i:1702524502;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="/thinkphp5/public/static/css/common.css">
    <link rel="stylesheet" href="/thinkphp5/public/static/css/mystyle6.css">
</head>
<body>
<h2>我的收藏</h2>
<div class="info">
    <?php if(empty(\think\Session::get('user.username')) || ((\think\Session::get('user.username') instanceof \think\Collection || \think\Session::get('user.username') instanceof \think\Paginator ) && \think\Session::get('user.username')->isEmpty())): ?>
    <div class="welcome">
        <a href="<?php echo url('index/user/login'); ?>">登录</a>
        <a href="<?php echo url('index/user/register'); ?>">注册</a>
    </div>
    <?php else: ?>
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<div class="welcome">
    欢迎您！<?php echo \think\Session::get('user.username'); ?>
    <a href="<?php echo url('index/user/editinfo'); ?>">修改个人信息</a>
</div>
</body>
</html>
    <div class="funclist">
        <?php if($count != '0'): ?>
        <a href="<?php echo url('index/index/checkout'); ?>">结算订单</a>
        <?php endif; ?>
        <a href="<?php echo url('index/index/index'); ?>">宠物列表</a>
        <a href="<?php echo url('index/index/cart'); ?>">查看购物车</a>
        (当前包含<span class="count"><?php echo $count; ?></span>种商品)
        <a href="<?php echo url('index/user/logout'); ?>">退出登录</a>

    </div>
    <?php endif; ?>
</div>
<div class="main">
    <div class="categorylist">
        <?php if(is_array($catlist) || $catlist instanceof \think\Collection || $catlist instanceof \think\Paginator): $i = 0; $__LIST__ = $catlist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$catitem): $mod = ($i % 2 );++$i;?>
        <div class="category">
            <img src="/thinkphp5/public/static/commimages/heart.png" alt="" class="littleimg">
            <a href="<?php echo url('index?cid='.$catitem['categoryid']); ?>"><?php echo $catitem['name']; ?></a>
        </div>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
    <div id="content">
        <div class="info2">
            <h3><strong> 当前包含<span class="count"><?php echo $fcount; ?></span>种商品</strong></h3>
        </div>
        <div class="prodlist">
            <table id="table1">
                <tr class="coltitle">
                    <td>操作</td>
                    <td>图片</td>
                    <td>商品</td>
                    <td>单价</td>
                    <td colspan="3">数量</td>
                </tr>
                <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
                <tr class="message">
                    <td class="littletd">
                        <a href="<?php echo url('delformfavorite?pid='.$item['productid']); ?>">
                            <img src="/thinkphp5/public/static/commimages/btnDelete.png" alt="删除" class="btnimg">
                        </a>
                        <a href="<?php echo url('addprodtocart2?pid='.$item['productid']); ?>">
                            <img src="/thinkphp5/public/static/commimages/btnCart.png" alt="放入购物车" class="btnimg">
                        </a>
                    </td>
                    <td>
                        <a href="<?php echo url('showproduct?pid='.$item['productid']); ?>">
                            <img src="/thinkphp5/public/static/<?php echo $item['image']; ?>" alt="<?php echo $item['productname']; ?>" class="proimg">
                        </a>
                    </td>
                    <td><?php echo $item['productname']; ?></td>
                    <td><?php echo $item['unitprice']; ?></td>
                    <td class="littletd">
                        <a href="<?php echo url('decreasefavorite?pid='.$item['productid']); ?>">
                            <img src="/thinkphp5/public/static/commimages/button-back.gif" alt="减少" class="btnimg">
                        </a>
                    </td>
                    <td>
                        <?php $__FOR_START_16299__=0;$__FOR_END_16299__=$item['star'];for($i=$__FOR_START_16299__;$i < $__FOR_END_16299__;$i+=1){ ?>
                        <img src="/thinkphp5/public/static/commimages/star.jpg" class="starimg">
                        <?php } $__FOR_START_572__=$item['star'];$__FOR_END_572__=5;for($i=$__FOR_START_572__;$i < $__FOR_END_572__;$i+=1){ ?>
                        <img src="/thinkphp5/public/static/commimages/star1.jpg" class="starimg">
                        <?php } ?>
                    </td>
                    <td class="littletd">
                        <a href="<?php echo url('increasefavorite?pid='.$item['productid']); ?>">
                            <img src="/thinkphp5/public/static/commimages/button-continue.gif" alt="增加" class="btnimg">
                        </a>
                    </td>
                </tr>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </table>
        </div>
    </div>
</div>

</body>
</html>