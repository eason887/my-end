<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:81:"C:\phpStudy\PHPTutorial\WWW\2077\public/../application/index\view\user\login.html";i:1701917340;s:77:"C:\phpStudy\PHPTutorial\WWW\2077\application\index\view\index\divwelcome.html";i:1701917644;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>登录</title>
    <link rel="stylesheet" href="/thinkphp5/public/static/css/common.css" />
    <link rel="stylesheet" href="/thinkphp5/public/static/css/mystyle1.css" />
</head>
<body>
<h2>用户登录</h2>
<div class="info">
    <?php if(empty(\think\Session::get('user.username')) || ((\think\Session::get('user.username') instanceof \think\Collection || \think\Session::get('user.username') instanceof \think\Paginator ) && \think\Session::get('user.username')->isEmpty())): ?>
    <div class="welcome">
        <a href="<?php echo url('index/user/login'); ?>">登录</a>
        <a href="<?php echo url('index/user/register'); ?>">注册</a>
    </div>
    <?php else: ?>
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<div class="welcome">
    欢迎您！<?php echo \think\Session::get('user.username'); ?>，
    <a href="<?php echo url('index/user/editinfo'); ?>">修改个人信息</a>
</div>
</body>
</html>
    <div class="funclist">
        <a href="<?php echo url('index/index/cart'); ?>">查看购物车</a>
        (当前包含<span class="count"><?php echo $count; ?></span>种商品)
        <a href="<?php echo url('index/user/logout'); ?>">退出登录</a>

    </div>
    <?php endif; ?>
</div>
<div class="main">
    <div class="categorylist">
        <?php if(is_array($catlist) || $catlist instanceof \think\Collection || $catlist instanceof \think\Paginator): $i = 0; $__LIST__ = $catlist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$catitem): $mod = ($i % 2 );++$i;?>
        <div class="category">
            <img src="/thinkphp5/public/static/commimages/heart.png" alt="" class="littleimg">
            <a href="<?php echo url('index/index?cid='.$catitem['categoryid']); ?>"><?php echo $catitem['name']; ?></a>
        </div>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
    <div id="content">
        <form action="<?php echo url('index/user/dologin'); ?>" method="post">
            <table>
                <tr>
                    <td class="ttd"><label for="username">用户名</label></td>
                    <td><input type="text" name="username" id="username" required></td>
                </tr>
                <tr>
                    <td class="ttd"><label for="password">密码</label></td>
                    <td><input type="password" name="password" id="password" required></td>
                </tr>
                <tr>
                    <td  class="ttd">
                        <label for="code">验证码</label>
                    </td>
                    <td>
                        <input type="text" name="code" id="varifycode" required>
                    </td>
                    <td>
                        <img src="<?php echo url('index/verifycode/getverifycode'); ?>" alt="" onclick="this.src='<?php echo url('index/verifycode/getverifycode'); ?>?'+Math.random();">
                    </td>
                </tr>
                <tr>
                    <td class="ttd">用户类型</td>
                    <td>
                        <input type="checkbox" name="admin" value="admin" checked="checked">管理员
                    </td>
                </tr>
                <tr>
                    <td colspan="2" align="center">
                        <button>登录</button>
                        <button type="reset">重置</button>
                    </td>
                </tr>
                
            </table>
        </form>
        <p class="p1">
            <a href="<?php echo url('index/user/register'); ?>">没有账号？点击注册</a>
        </p>
    </div>
</div>
</body>
</html>