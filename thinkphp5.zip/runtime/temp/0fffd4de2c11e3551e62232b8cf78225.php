<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:93:"C:\phpStudy\PHPTutorial\WWW\thinkphp5\public/../application/index\view\index\productlist.html";i:1701912820;s:82:"C:\phpStudy\PHPTutorial\WWW\thinkphp5\application\index\view\index\divwelcome.html";i:1702524504;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>

    <link rel="stylesheet" href="/thinkphp5/public/static/css/common.css" />
    <link rel="stylesheet" href="/thinkphp5/public/static/css/mystyle2.css" />
</head>
<body>
<h2>宠物列表</h2>

<div class="info">
    <?php if(empty(\think\Session::get('user.username')) || ((\think\Session::get('user.username') instanceof \think\Collection || \think\Session::get('user.username') instanceof \think\Paginator ) && \think\Session::get('user.username')->isEmpty())): ?>
    <div class="welcome">
        <a href="<?php echo url('index/user/login'); ?>">登录</a>
        <a href="<?php echo url('index/user/register'); ?>">注册</a>
    </div>
    <?php else: ?>
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<div class="welcome">
    欢迎您！<?php echo \think\Session::get('user.username'); ?>
    <a href="<?php echo url('index/user/editinfo'); ?>">修改个人信息</a>
</div>
</body>
</html>
    <div class="funclist">
        <?php if($count != '0'): ?>
            <a href="<?php echo url('index/index/checkout'); ?>">结算订单</a>
        <?php endif; ?>
        <a href="<?php echo url('index/index/index'); ?>">宠物列表</a>
        <a href="<?php echo url('index/index/favorite'); ?>">查看收藏</a>
        <a href="<?php echo url('index/index/cart'); ?>">查看购物车</a>
        (当前包含<span class="count"><?php echo $count; ?></span>种商品)
        <a href="<?php echo url('index/user/logout'); ?>">退出登录</a>

    </div>
    <?php endif; ?>
</div>
<div class="main">
    <div class="categorylist">
        <?php if(is_array($catlist) || $catlist instanceof \think\Collection || $catlist instanceof \think\Paginator): $i = 0; $__LIST__ = $catlist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$catitem): $mod = ($i % 2 );++$i;?>
        <div class="category">
            <img src="/thinkphp5/public/static/commimages/heart.png" alt="" class="littleimg">
            <a href="<?php echo url('index?cid='.$catitem['categoryid']); ?>"><?php echo $catitem['name']; ?></a>
        </div>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
    <div id="content">
        <div class="prodlist">
            <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;if($mod == '1'): ?>
                <div class="message">
                    <div class="leftcontent">
                        <table>
                            <tr>
                                <td width="105">
                                    <a href="<?php echo url('showproduct?pid='.$item['productid']); ?>">
                                    <img src="/thinkphp5/public/static/<?php echo $item['image']; ?>" alt="<?php echo $item['productname']; ?>" class="proimg">
                                    </a>
                                </td>
                                <td width="100"><p class="ptitle"><?php echo $item['productname']; ?></p></td>
                                <td>单价:<?php echo $item['unitprice']; ?>元<br/>
                                    描述:<?php echo $item['descn']; ?><br/></td>
                            </tr>
                        </table>
                    </div>

                    <div class="subinforight">
                        <a href="<?php echo url('addprodtocart?pid='.$item['productid']); ?>">
                            <img src="/thinkphp5/public/static/commimages/button-cart.gif" alt="放入购物车" class="littleimg">
                        </a>
                        <a href="<?php echo url('addprodtofavorite?pid='.$item['productid']); ?>">
                            <img src="/thinkphp5/public/static/commimages/button-wishlist.gif" alt="我的最爱" class="littleimg">
                        </a>
                    </div>
                </div>
            <?php endif; if($mod == '0'): ?>
            <div class="message2">
                <div class="leftcontent">
                    <table>
                        <tr>
                            <td width="105">
                                <a href="<?php echo url('showproduct?pid='.$item['productid']); ?>">
                                <img src="/thinkphp5/public/static/<?php echo $item['image']; ?>" alt="<?php echo $item['productname']; ?>" class="proimg">
                                </a>
                            </td>
                            <td width="100"><p class="ptitle"><?php echo $item['productname']; ?></p></td>
                            <td>单价:<?php echo $item['unitprice']; ?>元<br/>
                                描述:<?php echo $item['descn']; ?><br/></td>
                        </tr>
                    </table>
                </div>

                <div class="subinforight">
                    <a href="<?php echo url('addprodtocart?pid='.$item['productid']); ?>">
                        <img src="/thinkphp5/public/static/commimages/button-cart.gif" alt="放入购物车" class="littleimg">
                    </a>
                    <a href="<?php echo url('addprodtofavorite?pid='.$item['productid']); ?>">
                        <img src="/thinkphp5/public/static/commimages/button-wishlist.gif" alt="我的最爱" class="littleimg">
                    </a>
                </div>
            </div>
            <?php endif; endforeach; endif; else: echo "" ;endif; ?>
            <div class="pages">
                <?php echo $list->render(); ?>
            </div>
        </div>
    </div>
</div>
</body>
</html>