<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:92:"C:\phpStudy\PHPTutorial\WWW\thinkphp5\public/../application/admin\view\index\addproduct.html";i:1701834592;s:84:"C:\phpStudy\PHPTutorial\WWW\thinkphp5\application\admin\view\index\admindivinfo.html";i:1701740560;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>新增宠物</title>
    <link rel="stylesheet" href="/thinkphp5/public/static/css/common.css" />
    <link rel="stylesheet" href="/thinkphp5/public/static/css/mystyle1.css" />
</head>
<body>
<h2>新增宠物</h2>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<div class="info">
    <?php if(empty(\think\Session::get('user.username')) || ((\think\Session::get('user.username') instanceof \think\Collection || \think\Session::get('user.username') instanceof \think\Paginator ) && \think\Session::get('user.username')->isEmpty())): ?>
    <div class="welcome">
        <a href="<?php echo url('index/user/login'); ?>">登录</a>
        <a href="<?php echo url('index/user/register'); ?>">注册</a>
    </div>
    <?php else: ?>
    <div class="welcome">欢迎您！管理员（<?php echo \think\Session::get('user.username'); ?>）
    </div>
    <div class="funclist">
        <a href="<?php echo url('index/user/logout'); ?>">退出登录</a>
    </div>
    <?php endif; ?>
</div>
</body>
</html>
<div class="main">
    <div class="categorylist">
        <div class="category">
            <img src="/thinkphp5/public/static/commimages/btnnodeFunction.png" alt="" class="littleimg">
            <a href="<?php echo url('index/addproduct'); ?>">新增宠物</a>
        </div>
        <div class="category">
            <img src="/thinkphp5/public/static/commimages/btnnodeFunction.png" alt="" class="littleimg">
            <a href="<?php echo url('index/prodlist'); ?>">编辑宠物</a>
        </div>
        <div class="category">
            <img src="/thinkphp5/public/static/commimages/btnnodeFunction.png" alt="" class="littleimg">
            <a href="<?php echo url('index/adduser'); ?>">新增用户</a>
        </div>
        <div class="category">
            <img src="/thinkphp5/public/static/commimages/btnnodeFunction.png" alt="" class="littleimg">
            <a href="<?php echo url('index/userlist'); ?>">编辑用户</a>
        </div>
    </div>
    <div class="content">
        <form action="<?php echo url('admin/index/doaddproduct'); ?>" enctype="multipart/form-data" method="post">
            <table>
                <tr>
                    <td class="ttd"><label for="proname">宠物名</label></td>
                    <td><input type="text" name="proname" id="username" required></td>
                </tr>
                <tr>
                    <td class="ttd"><label for="category">宠物类别</label></td>
                    <td>
                        <select name="category" id="">
                            <?php if(is_array($catlist) || $catlist instanceof \think\Collection || $catlist instanceof \think\Paginator): $i = 0; $__LIST__ = $catlist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$catitem): $mod = ($i % 2 );++$i;?>
                                <option value="<?php echo $catitem['categoryid']; ?>"><?php echo $catitem['name']; ?></option>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td class="ttd"><label for="price">价格</label></td>
                    <td><input type="text" name="price" id="phone" value="100.00" required></td>
                </tr>
                <tr>
                    <td class="ttd"><label for="des">描述</label></td>
                    <td><input type="text" name="des" id="phone" value="非常可爱的小东西" required></td>
                </tr>
                <tr>
                    <td class="ttd"><label for="proimage">上传图片</label></td>
                    <td><input type="file" name="proimage" ></td>
                </tr>
                <tr>
                    <td colspan="2" align="center">
                        <button>新增</button>
                        <button type="reset">重置</button>
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>
</body>
</html>