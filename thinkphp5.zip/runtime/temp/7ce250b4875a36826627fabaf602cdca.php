<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:81:"C:\phpStudy\PHPTutorial\WWW\2077\public/../application/index\view\index\cart.html";i:1701912820;s:77:"C:\phpStudy\PHPTutorial\WWW\2077\application\index\view\index\divwelcome.html";i:1702524502;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="/thinkphp5/public/static/css/common.css" />
    <link rel="stylesheet" href="/thinkphp5/public/static/css/mystyle3.css" />
</head>
<body>
<h2>购物车</h2>

<div class="info">
    <?php if(empty(\think\Session::get('user.username')) || ((\think\Session::get('user.username') instanceof \think\Collection || \think\Session::get('user.username') instanceof \think\Paginator ) && \think\Session::get('user.username')->isEmpty())): ?>
    <div class="welcome">
        <a href="<?php echo url('index/user/login'); ?>">登录</a>
        <a href="<?php echo url('index/user/register'); ?>">注册</a>
    </div>
    <?php else: ?>
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<div class="welcome">
    欢迎您！<?php echo \think\Session::get('user.username'); ?>
    <a href="<?php echo url('index/user/editinfo'); ?>">修改个人信息</a>
</div>
</body>
</html>
    <div class="funclist">
        <?php if($count != '0'): ?>
            <a href="<?php echo url('index/index/checkout'); ?>">结算订单</a>
        <?php endif; ?>
        <a href="<?php echo url('index/index/index'); ?>">宠物列表</a>
        <a href="<?php echo url('index/index/favorite'); ?>">查看收藏</a>
        <a href="<?php echo url('index/index/index'); ?>">宠物列表</a>
        <a href="<?php echo url('index/user/logout'); ?>">退出登录</a>
    </div>
    <?php endif; ?>
</div>
<div class="main">
    <div class="categorylist">
        <?php if(is_array($catlist) || $catlist instanceof \think\Collection || $catlist instanceof \think\Paginator): $i = 0; $__LIST__ = $catlist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$catitem): $mod = ($i % 2 );++$i;?>
        <div class="category">
            <img src="/thinkphp5/public/static/commimages/heart.png" alt="" class="littleimg">
            <a href="<?php echo url('index?cid='.$catitem['categoryid']); ?>"><?php echo $catitem['name']; ?></a>
        </div>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
    <div id="content">
        <div class="info2">
            <h3><strong>当前包含<span class="count"><?php echo $count; ?></span>种商品,共计=<?php echo $sumprice; ?>元</strong></h3>

        </div>
        <div class="prodlist">
            <table id="table1">
                <tr class="coltitle">
                    <td>操作</td>
                    <td>图片</td>
                    <td>商品</td>
                    <td>单价</td>
                    <td colspan="3">数量</td>
                    <td>总价</td>
                </tr>
        <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;if($mod == '1'): ?>
                <tr class="message">
                    <td class="littletd">
                        <a href="<?php echo url('delformcart?pid='.$item['productid']); ?>">
                            <img src="/thinkphp5/public/static/commimages/button-delete.gif" alt="删除" class="btnimg">
                        </a>
                    </td>
                    <td>
                        <a href="<?php echo url('showproduct?pid='.$item['productid']); ?>">
                            <img src="/thinkphp5/public/static/<?php echo $item['image']; ?>" alt="<?php echo $item['productname']; ?>" class="proimg">
                        </a>
                    </td>
                    <td><?php echo $item['productname']; ?></td>
                    <td><?php echo $item['unitprice']; ?></td>
                    <td class="littletd">
                        <a href="<?php echo url('decrease?pid='.$item['productid']); ?>">
                            <img src="/thinkphp5/public/static/commimages/button-back.gif" alt="减少" class="btnimg">
                        </a>
                    </td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td class="littletd">
                        <a href="<?php echo url('increase?pid='.$item['productid']); ?>">
                            <img src="/thinkphp5/public/static/commimages/button-continue.gif" alt="增加" class="btnimg">
                        </a>
                    </td>
                    <td><?php echo $item['sum']; ?>元</td>
                </tr>
                <?php endif; if($mod == '0'): ?>
                <tr class="message2">
                    <td class="littletd">
                        <a href="<?php echo url('delformcart?pid='.$item['productid']); ?>">
                            <img src="/thinkphp5/public/static/commimages/button-delete.gif" alt="删除" class="btnimg">
                        </a>
                    </td>
                    <td>
                        <a href="<?php echo url('showproduct?pid='.$item['productid']); ?>">
                            <img src="/thinkphp5/public/static/<?php echo $item['image']; ?>" alt="<?php echo $item['productname']; ?>" class="proimg">
                        </a>
                    </td>
                    <td><?php echo $item['productname']; ?></td>
                    <td><?php echo $item['unitprice']; ?></td>
                    <td class="littletd">
                        <a href="<?php echo url('decrease?pid='.$item['productid']); ?>">
                            <img src="/thinkphp5/public/static/commimages/button-back.gif" alt="减少" class="btnimg">
                        </a>
                    </td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td class="littletd">
                        <a href="<?php echo url('increase?pid='.$item['productid']); ?>">
                            <img src="/thinkphp5/public/static/commimages/button-continue.gif" alt="增加" class="btnimg">
                        </a>
                    </td>
                    <td><?php echo $item['sum']; ?>元</td>
                </tr>
                <?php endif; endforeach; endif; else: echo "" ;endif; ?>
            </table>
        </div>
    </div>
</div>
</body>
</html>