<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:90:"C:\phpStudy\PHPTutorial\WWW\thinkphp5\public/../application/admin\view\index\edituser.html";i:1702542664;s:84:"C:\phpStudy\PHPTutorial\WWW\thinkphp5\application\admin\view\index\admindivinfo.html";i:1701740560;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>修改用户</title>
    <link rel="stylesheet" href="/thinkphp5/public/static/css/common.css" />
    <link rel="stylesheet" href="/thinkphp5/public/static/css/mystyle1.css" />
    <style type="text/css">
        .proimg
        {
            width: 60px;
            height: 60px;
        }
    </style>
</head>
<body>
<h2>修改用户</h2>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<div class="info">
    <?php if(empty(\think\Session::get('user.username')) || ((\think\Session::get('user.username') instanceof \think\Collection || \think\Session::get('user.username') instanceof \think\Paginator ) && \think\Session::get('user.username')->isEmpty())): ?>
    <div class="welcome">
        <a href="<?php echo url('index/user/login'); ?>">登录</a>
        <a href="<?php echo url('index/user/register'); ?>">注册</a>
    </div>
    <?php else: ?>
    <div class="welcome">欢迎您！管理员（<?php echo \think\Session::get('user.username'); ?>）
    </div>
    <div class="funclist">
        <a href="<?php echo url('index/user/logout'); ?>">退出登录</a>
    </div>
    <?php endif; ?>
</div>
</body>
</html>
<div class="main">
    <div class="categorylist">
        <div class="category">
            <img src="/thinkphp5/public/static/commimages/btnnodeFunction.png" alt="" class="littleimg">
            <a href="<?php echo url('index/addproduct'); ?>">新增宠物</a>
        </div>
        <div class="category">
            <img src="/thinkphp5/public/static/commimages/btnnodeFunction.png" alt="" class="littleimg">
            <a href="<?php echo url('index/prodlist'); ?>">编辑宠物</a>
        </div>
        <div class="category">
            <img src="/thinkphp5/public/static/commimages/btnnodeFunction.png" alt="" class="littleimg">
            <a href="<?php echo url('index/adduser'); ?>">新增用户</a>
        </div>
        <div class="category">
            <img src="/thinkphp5/public/static/commimages/btnnodeFunction.png" alt="" class="littleimg">
            <a href="<?php echo url('index/userlist'); ?>">编辑用户</a>
        </div>
    </div>
    <div class="content">
        <form action="<?php echo url('doedituser'); ?>" method="post">
            <table>
                <tr>
                    <td class="ttd"><label for="username">用户名</label></td>
                    <td><input type="text" name="username" id="username" value="<?php echo $useritem['username']; ?>" readonly="readonly"></td>
                </tr>
                <tr>
                    <td class="ttd"><label for="truename">真实姓名</label></td>
                    <td><input type="text" name="truename" id="truename" value="<?php echo $useritem['username']; ?>" required></td>
                </tr>
                <tr>
                    <td class="ttd"><label for="sex">性别</label></td>
                    <?php if($useritem['sex'] == '男'): ?>
                    <td>
                        <input type="radio" name="sex" value="male" checked="checked">男
                        <input type="radio" name="sex" value="female">女
                    </td>
                    <?php else: ?>
                    <td>
                        <input type="radio" name="sex" value="male">男
                        <input type="radio" name="sex" value="female" checked="checked">女
                    </td>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td class="ttd"><label for="email">邮箱地址</label></td>
                    <td><input type="email" name="email" id="email" value="<?php echo $useritem['email']; ?>"></td>
                </tr>
                <tr>
                    <td class="ttd"><label for="address">通讯地址</label></td>
                    <td><input type="text" name="address" id="address" value="<?php echo $useritem['address']; ?>"></td>
                </tr>
                <tr>
                    <td class="ttd"><label for="phone">联系电话</label></td>
                    <td><input type="text" name="phone" id="phone" value="<?php echo $useritem['phone']; ?>"></td>
                </tr>
                <tr>
                    <td colspan="2" align="center">
                        <button>新增</button>
                        <button type="reset">重置</button>
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>
</body>
</html>