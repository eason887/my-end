<?php
namespace app\admin\controller;
use app\index\model\User as UserModel;
use think\Controller;
use think\Db;

class Index extends Controller
{
    private function checkLogin()
    {
        if(!session('user.userId'))
        {
            $this->error('请登录','index/User/login');
        }
        if(session('user.usertype')!="admin")
        {
            $this->error('请用管理员方式登录','index/User/login');
        }
    }
    public function index()
    {
        $count = Db::table('account')->count();
        $this->assign('count',$count);
        $list = Db::table('account')
            ->order('username')
            ->paginate(5);
        $this->assign('list',$list);
        return $this->fetch("index");
    }
    public function addproduct()
    {
        $this->checkLogin();
        $catlist = Db::table("category")->select();
        $this->assign('catlist',$catlist);
        return $this->fetch();
    }
    public function doaddproduct()
    {
        $proname = input('post.proname');
        $category = input('post.category');
        $price = input('post.price');
        $des = input('post.des');
        $file = request()->file('proimage');
        $info = $file->validate(['ext'=>'jpg,png,gif'])
            ->move(ROOT_PATH .'public'.DS .'static'.DS .'prodimages','');
        if($info)
        {
            $imagefile = $info->getFilename();
        }
        else
        {
            $imagefile = "";
        }
        $addsql = 'INSERT product(categoryid,productname,descn,image,unitprice)';
        $addsql.= 'VALUES(:categoryid,:productname,:descn,:image,:unitprice)';
        $res = Db::execute($addsql,
            ['categoryid'=>$category,
                'productname'=>$proname,
                'descn'=>$des,
                'image'=>"prodimages/".$imagefile,
                'unitprice'=>$price]);
        if ($res==1)
            $this->success("新增宠物成功！",'Index/prodlist');
        else
            $this->error("新增失败！");
    }
    public function prodlist()
    {
        $this->checkLogin();
        $count = Db::table('product')->count();
        $this->assign('count',$count);
        $list = Db::view('category','categoryid,name')
            ->view('product',['productname','image','unitprice','productid'],
                'category.categoryid = product.categoryid')
            ->order('productid')
            ->paginate(5);
        $this->assign('list',$list);
        return $this->fetch("prodlist");
    }
    public function delproduct($pid)
    {
        $this->checkLogin();
        Db::execute('DELETE FROM product WHERE productid=:productid',
            ['productid'=>$pid]);
        return $this->prodlist();
    }
    public function editproduct($pid)
    {
        $this->checkLogin();
        $catlist = Db::table("category")->select();
        $this->assign('catlist',$catlist);
        $prod = Db::table('product')
            ->where('productid',$pid)
            ->find();
        $this->assign('proditem',$prod);
        return $this->fetch();
    }
    public function doeditproduct()
    {
        $pid = input('post.pid');
        $proname = input('post.proname');
        $category = input('post.category');
        $price = input('post.price');
        $des = input('post.des');
        $file = request()->file('proimage');
        if (!empty($file))
        {
            $info = $file->validate(['ext'=>'jpg,png,gif'])
                ->move(ROOT_PATH . 'public' . DS . 'static' . DS . 'prodimages','');
            if ($info)
                $imagefile = $info->getFilename();
            else
                $imagefile="";
        }
        else
            $imagefile="";

        $editsql = 'UPDATE product SET categoryid=:categoryid,productname=:productname,';
        if ($imagefile=="")
            $editsql.='descn=:descn,unitprice=:unitprice ';
        $editsql.='WHERE productid=:productid ';

        if ($imagefile=="")
            $res=Db::execute($editsql,
                ['categoryid'=>$category,
                    'productname'=>$proname,
                    'descn'=>$des,
                    'productid'=>$pid,
                    'unitprice'=>$price]);
        else
            $res=Db::execute($editsql,
                ['categoryid'=>$category,
                    'productname'=>$proname,
                    'descn'=>$des,
                    'image'=>"prodimages/".$imagefile,
                    'productid'=>$pid,
                    'unitprice'=>$price]);
        if ($res==1)
            $this->success("修改宠物成功！",'prodlist');
        else
            $this->error("修改失败！");
    }
    public function userlist()
    {
        $this->checkLogin();
        $count = Db::table('account')->count();
        $this->assign('count',$count);
        $list = Db::table('account')
            ->order('username')
            ->paginate(5);
        $this->assign('list',$list);
        return $this->fetch('userlist');
    }
    public function deluser($uid)
    {
        $this->checkLogin();
        Db::execute('DELETE FROM account WHERE username=:username',
            ['username'=>$uid]);
        return $this->userlist();
    }
    public function adduser()
    {
        $this->checkLogin();
        return $this->fetch();
    }
    public function doadduser()
    {
        $username = input('post.username');
        $truename = input('post.truename');
        $sex = input('post.sex');
        if ($sex=="male")
            $sex="男";
        else
            $sex="女";
        $email = "用户未填";
        $address = "用户未填";
        $phone = "用户未填";
        if (empty($username))
        {
            $this->error('用户名不能为空');
        }
        $user = UserModel::getByUsername($username);
        if (!empty($user))
        {
            $this->error('用户名已存在');
        }
        $data = array(
            'username' => $username,
            'password' => md5($username),
            'truename' => $truename,
            'sex' => $sex,
            'email' => $email,
            'address' => $address,
            'phone' => $phone
        );
        if ($result = UserModel::create($data))
        {
            $this->success('新增用户成功，密码等于用户名','userlist');
        }
        else
        {
            $this->error('新增用户失败');
        }
    }
    public function edituser($uid)
    {
        $this->checkLogin();
        $user = Db::table('account')
            ->where('username',$uid)
            ->find();
        $this->assign('useritem',$user);
        return $this->fetch();
    }
    public function doedituser()
    {
        $username = input('post.username');
        $truename = input('post.truename');
        $sex = input('post.sex');
        if($sex=="male")
            $sex="男";
        else
            $sex="女";
        $email = input('post.email');
        $address = input('post.address');
        $phone = input('post.phone');
        $data = array(
            'username' => $username,
            'truename' => $truename,
            'sex' => $sex,
            'email' => $email,
            'address' => $address,
            'phone' => $phone
        );
        $editsql='UPDATE account SET truename=:truename,sex=:sex,';
        $editsql.='email=:email,address=:address,phone=:phone ';
        $editsql.='WHERE username=:username ';
        $res = Db::execute($editsql,$data);
        $this->success('修改用户成功','userlist');
    }
    public function resetpass($uid)
    {
        $editsql='UPDATE account SET password=:pass';
        $editsql.=' WHERE username=:username ';
        $res=Db::execute($editsql,['username' => $uid,'pass' => md5($uid)]);
        $this->success('密码已经重置成功，新密码等于用户名！','userlist');
    }
}