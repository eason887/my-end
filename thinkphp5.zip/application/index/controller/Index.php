<?php
namespace app\index\controller;
use app\index\model\Message;

use think\Controller;
use think\Db;

class Index extends Controller
{
    //  检测登录
    private function checkLogin()
    {
        if(!session('user.userId'))
        {
            $this->error('请登录','User/login');
        }
    }
    public function index($cid='')
    {
        if($cid=='')
            session('product.catid',1);
        else
            session('product.catid',intval($cid));

        $catlist = Db::table("category")->select();
        $this->assign('catlist',$catlist);
        if(session('user.userId'))
        {
            $count = Db::table('cart')
                ->where('username',session('user.userId'))
                ->count();
            $this->assign('count',$count);
        }
        else
            $this->assign('count',0);

        $list = Db::table('product')
            ->where('categoryid','=',session('product.catid'))
            ->order('productid')
            ->paginate(4);
        $this->assign('list',$list);
        return $this->fetch("productlist");
    }

    public function addprodtocart($pid)
    {
        if(!session('user.userId'))
        {
            $this->error('请登录','User/login');
        }
        $count = Db::table('cart')
            ->where('username',session('user.userId'))
            ->where('productid',$pid)
            ->count();
        if($count>0)
            Db::execute('UPDATE cart SET quantity=quantity+1 WHERE username=:username AND productid=:productid',
                ['username'=>session('user.userId'),'productid'=>$pid]);
        else
            Db::execute('INSERT INTO cart (username,productid,Quantity) VALUES (:username,:productid,1)',
                ['username'=>session('user.userId'),'productid'=>$pid]);
        return $this->index(session('product.catid'));
    }
    public function showproduct($pid)
    {
        $catlist = Db::table("category")->select();
        $this->assign('catlist',$catlist);
        if(session('user.userId'))
        {
            $count = Db::table('cart')
                ->where('username',session('user.userId'))
                ->count();
            $this->assign('count',$count);
        }
        else
            $this->assign('count',0);

        $list = Db::view('category','name')
            ->view('product',['productid','productname','image','unitprice','descn'=>'pdescn'],
                'category.categoryid = product.categoryid')
            ->where('productid',$pid)->find();
        $this->assign('list',$list);
        return $this->fetch("showproduct");
    }
    public function cart()
    {
        $catlist = Db::table("category")->select();
        $this->assign('catlist',$catlist);
        if(session('user.userId'))
        {
            $count = Db::table('cart')
                ->where('username',session('user.userId'))
                ->count();
            $this->assign('count',$count);
        }
        else
            $this->assign('count',0);

        $list = Db::view('cart','productid,quantity')
            ->view('product',['productname','image','unitprice'],
                'cart.productid = product.productid')
            ->where('username',session('user.userId'))->select();
        $sum=0.0;
        for($i=0;$i<count($list);$i++)
        {
            $s=$list[$i]["unitprice"]*$list[$i]["quantity"];
            $list[$i]["sum"]=$s;
            $sum+=$list[$i]["unitprice"]*$list[$i]["quantity"];
        }
        $this->assign('sumprice',$sum);
        $this->assign('list',$list);
        return $this->fetch("cart");
    }

    public function decrease($pid)
    {
        $count = Db::table('cart')
            ->where('username',session('user.userId'))
            ->where('productid',$pid)
            ->value('quantity');
        if($count>1)
            Db::execute('UPDATE cart SET quantity=quantity-1 WHERE username=:username AND productid=:productid',
                ['username'=>session('user.userId'),'productid'=>$pid]);
        return $this->cart();
    }
    public function increase($pid)
    {
        Db::execute('UPDATE cart SET quantity=quantity+1 WHERE username=:username AND productid=:productid',
            ['username'=>session('user.userId'),'productid'=>$pid]);
        return $this->cart();
    }
    public function delformcart($pid)
    {
        Db::execute('DELETE FROM cart WHERE username=:username AND productid=:productid',
            ['username'=>session('user.userId'),'productid'=>$pid]);
        return $this->cart();
    }
    public function checkout()
    {
        $catlist = Db::table("category")->select();
        $this->assign('catlist',$catlist);
        if(session('user.userId'))
        {
            $count = Db::table('cart')
                ->where('username', session('user.userId'))
                ->count();
            $this->assign('count', $count);
        }
        else
            $this->assign('count',0);

        $list = Db::view('cart','productid,quantity')
            ->view('product',['productname','image','unitprice'],
                'cart.productid = product.productid')
            ->where('username',session('user.userId'))->select();
        $sum=0.0;
        for($i=0;$i<count($list);$i++)
        {
            $s=$list[$i]["unitprice"]*$list[$i]["quantity"];
            $list[$i]["sum"]=$s;
            $sum+=$list[$i]["unitprice"]*$list[$i]["quantity"];
        }
        $this->assign('sum',$sum);
        return $this->fetch("checkout");
    }
    public function docheckout()
    {
        $cardno = input('post.cardno');
        $expdate = input('post.expdate');
        $list = Db::view('cart','productid,quantity')
            ->view('product',['productname','image','unitprice'],
                'cart.productid = product.productid')
            ->where('username',session('user.userId'))->select();
        $sum=0.0;
        for($i=0;$i<count($list);$i++)
        {
            $s=$list[$i]["unitprice"]*$list[$i]["quantity"];
            $list[$i]["sum"]=$s;
            $sum+=$list[$i]["unitprice"]*$list[$i]["quantity"];
        }

        $result = Db::execute('call addorder( :username,:cardno,:expdate);',
            ['username' => session('user.userId'),
                'cardno' => $cardno,'expdate'=>$expdate]);

        $str='结算成功！';
        $str.="此次交易将从你的信用卡 $cardno 中划款合计￥ $sum 元。";
        //  $str.='如对本订单有任何疑问，请随时联系我们的客户服务。'
        $this->success($str,'Index/index');
    }
    public function favorite()
    {
        $catlist = Db::table("category")->select();
        $this->assign('catlist',$catlist);
        if (session('user.userId'))
        {
            $count = Db::table('cart')
                ->where('username',session('user.userId'))
                ->count();
            $this->assign('count',$count);
        }
        else
            $this->assign('count',0);
        if (session('user.userId'))
        {
            $count = Db::table('favorite')
                ->where('username',session('user.userId'))
                ->count();
            $this->assign('fcount',$count);
        }
        else
            $this->assign('fcount',0);
        $list = Db::view('favorite','username,productid,star')
            ->view('product',['productname','image','unitprice'],
                'favorite.productid = product.productid')
            ->where('username',session('user.userId'))->select();
        $this->assign('list',$list);
        return $this->fetch("favorite");
    }
    public function addprodtofavorite($pid)
    {
        if (!session('user.userId'))
        {
            $this->error('请登录','User/login');
        }
        $count = Db::table('favorite')
            ->where('username',session('user.userId'))
            ->where('productid',$pid)
            ->count();
        if ($count==0)
            Db::execute('INSERT INTO favorite (username,productid,star) VALUES (:username,:productid,1)',
                ['username'=>session('user.userId'),'productid'=>$pid]);
        return $this->index(session('product.catid'));
    }
    public function decreasefavorite($pid)
    {
        $count = Db::table('favorite')
            ->where('username',session('user.userId'))
            ->where('productid',$pid)
            ->value('star');
        if ($count>1)
            Db::execute('UPDATE favorite SET star=star-1 WHERE username=:username AND productid=:productid',
                ['username'=>session('user.userId'),'productid'=>$pid]);
        return $this->favorite();
    }
    public function increasefavorite($pid)
    {
        $count = Db::table('favorite')
            ->where('username',session('user.userId'))
            ->where('productid',$pid)
            ->value('star');
        if ($count<5)
            Db::execute('UPDATE favorite SET star=star+1 WHERE username=:username AND productid=:productid',
                ['username'=>session('user.userId'),'productid'=>$pid]);
        return $this->favorite();
    }
    public function delformfavorite($pid)
    {
        Db::execute('DELETE FROM favorite WHERE username=:username AND productid=:productid',
            ['username'=>session('user.userId'),'productid'=>$pid]);
        return $this->favorite();
    }
//    public function addprodtocart($pid)
//    {
//        $this->doaddtocart($pid);
//        return $this->index(session('product.catid'));
//    }
    public function addprodtocart2($pid)
    {
        $this->doaddtocart($pid);
        return $this->favorite();
    }
    public function doaddtocart($pid)
    {
        if (!session('user.userId'))
        {
            $this->error('请登录','User/login');
        }
        $count = Db::table('cart')
            ->where('username',session('user.userId'))
            ->where('productid',$pid)
            ->count();
        if ($count>0)
            Db::execute('UPDATE cart SET quantity=quantity+1 WHERE username=:username AND productid=:productid',
                ['username'=>session('user.userId'),'productid'=>$pid]);
        else
            Db::execute('INSERT INTO cart(username,productid,Quantity) VALUES (:username,:productid,1)',
                ['username'=>session('user.userId'),'productid'=>$pid]);
    }

}
