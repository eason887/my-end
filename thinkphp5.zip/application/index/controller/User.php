<?php
namespace app\index\controller;
use think\Db;
use think\Controller;
use app\index\model\User as UserModel;
use app\index\model\Admin as AdminModel;
use app\index\controller\Verifycode as Myverifycode;
class User extends Controller
{
    public function register() #注册页面
    {
        $catlist = Db::table("category")->select();
        $this->assign('catlist',$catlist);
        if(session('user.userId'))
        {
            $count = Db::table('cart')
                ->where('username',session('user.userId'))
                ->count();
            $this->assign('count',$count);
        }
        else
            $this->assign('count',0);
        return $this->fetch();
    }
    public function doregister() #注册操作
    {
        $username = input('post.username');
        $password = input('post.password');
        $repassword = input('post.repassword');
        $truename = input('post.truename');
        $sex = input('post.sex');
        if ($sex=="male")
            $sex="男";
        else
            $sex="女";
        $email = input('post.email');
        $address = input('post.address');
        $phone = input('post.phone');
        if(empty($username))
        {
            $this->error('用户名不能为空');
        }
        if(empty($password))
        {
            $this->error('密码不能为空');
        }
        if(empty($repassword))
        {
            $this->error('确认密码错误');
        }
        //检测用户是否已注册
        $user = UserModel::getByUsername($username);
        if(!empty($user))
        {
            $this->error('用户名已存在');
        }
        $data = array(
            'username' => $username,
            'password' => md5($password),
            'truename' => $truename,
            'sex' => $sex,
            'email' => $email,
            'address' => $address,
            'phone' => $phone
        );
        if ($result = UserModel::create($data)){
            $this->success('注册成功，请登录','login');
        }
        else{
            $this->error('注册失败');
        }
    }

    //用户登录
    public function login()
    {
        $catlist = Db::table("category")->select();
        $this->assign('catlist',$catlist);
        if(session('user.userId'))
        {
            $count = Db::table('cart')
                ->where('username',session('user.userId'))
                ->count();
            $this->assign('count',$count);
        }
        else
            $this->assign('count',0);
        return $this->fetch();
    }
    //登录处理
    public function dologin()
    {
        $username = input('post.username');
        $password = input('post.password');
        $admin = input('post.admin');
        $code = input('post.code');
        $captcha = new Myverifycode();

        if ($admin!="admin")
        {
            $user = UserModel::getByUsername($username);
            if (empty($user) || $user['password'] != md5($password))
            {
                $this->error('账号或密码错误');
            }
            //写入session
            if(!$captcha->checkverifycode($code))
            {
                $this->error('验证错误');
            }
            session('user.userId',$user['username']);
            session('user.username',$user['truename']);
            session('user.usertype',"user");
            //跳转首页
            $this->redirect('Index/index');
        }
        else
        {
            $user = AdminModel::getByUsername($username);
            if (empty($user) || $user['password'] != md5($password))
            {
                $this->error('账号或密码错误');
            }
            //写入session
            if(!$captcha->checkverifycode($code))
            {
                $this->error('验证错误');
            }

            session('user.userId',$user['username']);
            session('user.username',$user['truename']);
            session('user.usertype','admin');
            //跳转首页
            $this->redirect('admin/index/userlist');
        }

    }

    //退出登录
    public function logout()
    {
        if(!session('user.userId'))
        {
            $this->error('请登录');
        }
        session_destroy();
        $this->success('退出登录成功','Index/index');
    }
    public function editinfo()
    {
        $catlist = Db::table("category")->select();
        $this->assign('catlist',$catlist);
        if (session('user.userId'))
        {
            $count = Db::table('cart')
                ->where('username',session('user.userId'))
                ->count();
            $this->assign('count',$count);
        }
        else
            $this->assign('count',0);
        $uid = session('user.userId');
        $user = Db::table('account')
            ->where('username',$uid)
            ->find();
        $this->assign('useritem',$user);
        return $this->fetch('editinfo');
    }
    public function doeditinfo()
    {
        $username = input('post.username');
        $truename = input('post.truename');
        $sex = input('post.sex');
        if($sex=="male")
            $sex="男";
        else
            $sex="女";
        $email = input('post.email');
        $address = input('post.address');
        $phone = input('post.phone');
        $data = array(
            'username' => $username,
            'truename' => $truename,
            'sex' => $sex,
            'email' => $email,
            'address' => $address,
            'phone' => $phone
        );
        $editsql='UPDATE account SET truename=:truename,sex=:sex,';
        $editsql.='email=:email,address=:address,phone=:phone ';
        $editsql.='WHERE username=:username ';
        $res = Db::execute($editsql,$data);
        $user = UserModel::getByUsername($username);
        session('user.username',$user['truename']);
        $this->success('修改用户成功','Index/index');
    }

}