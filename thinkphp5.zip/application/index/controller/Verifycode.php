<?php
namespace app\index\controller;
use think\captcha\Captcha as Myverify;
use think\Controller;

class Verifycode extends Controller
{
    public function getverifycode()
    {
        $config=[
            'fontSize'=>20,
            'length'=>4,
            'useNoise'=>true,
            'codeSet'=>'abc123'
        ];
        $captcha = new Myverify($config);
        return $captcha->entry();
    }
    public function checkverifycode($code)
    {
        $captcha = new Myverify();
        return $captcha->check($code);
    }
}