<?php


namespace app\index\model;


use think\Model;

class User extends Model
{
//    关联account表
//    这俩都一样->protect $name="account"
    protected $table="account";
}